package com.pgr.springboot.relaxbinding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRelaxBindingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
