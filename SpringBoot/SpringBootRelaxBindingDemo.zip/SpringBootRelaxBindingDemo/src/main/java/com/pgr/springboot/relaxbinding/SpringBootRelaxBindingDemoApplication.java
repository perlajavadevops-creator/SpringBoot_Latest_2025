package com.pgr.springboot.relaxbinding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRelaxBindingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRelaxBindingDemoApplication.class, args);
	}

}
