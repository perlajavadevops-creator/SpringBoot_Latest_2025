package com.pgr.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpMvcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
